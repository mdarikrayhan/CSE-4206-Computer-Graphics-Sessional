A Opengl Computer Graphics project "Countryside Scenario" using C++ and Opengl.
A countryside scenario with river and ship. According to time, the light will change from day to night. In addition, the weather 
will change like in summer the scenario will be sunny and birds will fly in the sky.

The program is made with Codeblocks in Windows 10 and to execute the program OpneGl and glut should be installed properly and 
configured with CodeBlocks.
After installing glut in Windows, open Transformation in Code Blocks.
Build and then run the solution.
Transformation.cpp is the main source C++ file.
    
This are the Controls:
"d" day Mode.
"n" night Mode.
"r" rain Mode.

![Image of Project](https://raw.githubusercontent.com/nozibuddowla/Transformation/master/Readme/Screenshot%20(86).png "Day View")
![Image of Project](https://raw.githubusercontent.com/nozibuddowla/Transformation/master/Readme/Screenshot-(87).jpg "Night View")
![Image of Project](https://raw.githubusercontent.com/nozibuddowla/Transformation/master/Readme/Screenshot-(88).jpg "Rainy Night View")
![Image of Project](https://raw.githubusercontent.com/nozibuddowla/Transformation/master/Readme/Screenshot-(89).jpg "Rainy Day View")
